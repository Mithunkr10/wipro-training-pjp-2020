package list;

import java.util.Vector;

/*Write a Java program to create an Vector, add all the months of a year and print the same.*/
public class Vectors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vector<String> al=new Vector<String>();
al.add("Jan" );
al.add("Feb");
al.add("Mar");
al.add("April");
al.add("May");
al.add("Jun");
al.add("July");
al.add("Aug");
al.add("Sept");
al.add("Oct");
al.add("Nov");
al.add("Dec");
System.out.println(al);
	}

}
