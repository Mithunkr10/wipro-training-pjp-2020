package list;

import java.util.*;

/*Write a Java program to create an LinkedList, add all the months of a year and print the same.*/

public class Linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList al=new LinkedList();
		al.add("Jan" );
		al.add("Feb");
		al.add("Mar");
		al.add("April");
		al.add("May");
		al.add("Jun");
		al.add("July");
		al.add("Aug");
		al.add("Sept");
		al.add("Oct");
		al.add("Nov");
		al.add("Dec");
		System.out.println("Original contents of ll: " + al);
	}

}
