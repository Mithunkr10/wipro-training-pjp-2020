package com.wipro.bean;

import java.util.List;

/*
4 There are two Model classes as below:
Student
studentId -> String -> S001
studentName -> String -> Steve
studentTest -> Object of type Test

Test
testId -> String -> T001
testTitle -> String -> “Core Java Test”
testMarks -> int -> 80

Create a spring program to create 2 student instances. 
First student has taken up the test with Core Java Test with 80 as score and the Second student has taken Oracle test with 83 as score.
In the client program display all the details of both the students along with their test details as well.

*/
public class SpringIOC4 {
	//public class Student
	private List<String> studentId;
	private List<String> studentName;
	private Test t;
	public SpringIOC4(List<String> studentId, List<String> studentName, Test t) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.t = t;
	}
	public SpringIOC4() {
		super();
		// TODO Auto-generated constructor stub
	}
	public List<String> getStudentId() {
		return studentId;
	}
	public void setStudentId(List<String> studentId) {
		this.studentId = studentId;
	}
	public List<String> getStudentName() {
		return studentName;
	}
	public void setStudentName(List<String> studentName) {
		this.studentName = studentName;
	}
	public Test getT() {
		return t;
	}
	public void setT(Test t) {
		this.t = t;
	}
	@Override
	public String toString() {
		return "SpringIOC4 [studentId=" + studentId + ", studentName=" + studentName + ", t=" + t + "]";
	}

}
