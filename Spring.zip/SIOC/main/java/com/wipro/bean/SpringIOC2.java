package com.wipro.bean;

/*
2 Create a class called ConstructorMessage with a single member variable called message which is initialized with null.
The class will have a parameterized constructor which initializes the member variable called message. 
Instantiate this class using Inversion control and test. [Perform Constructor Injection]
*/
public class SpringIOC2 {

	private ConstructMessage cm;

	public SpringIOC2(ConstructMessage cm) {
		super();
		this.cm = cm;
	}

	public ConstructMessage getCm() {
		return cm;
	}

	public void setCm(ConstructMessage cm) {
		this.cm = cm;
	}

	@Override
	public String toString() {
		return "SpringIOC2 [cm=" + cm + "]";
	}
	

}
