package com.wipro.bean;

public class Student {
private String studentId;
private String studentName;
private Test t;
}
