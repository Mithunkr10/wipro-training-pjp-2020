package com.wipro.services;


public interface CustomerService {
	
	public double NewBalance(double balance,float offerPercentage);

}
