package com.wipro.bean;

/*2 Create a class called DefaultMessage with a single member variable called message which is initialized with a default value "Spring". 
Instantiate this class and test
*/
public class SpringBasics2 {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "SpringBasics2 [message=" + message + "]";
	}
	

}
