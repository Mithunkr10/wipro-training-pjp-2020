CREATE TABLE EMP
(ID numeric(7) PRIMARY KEY,LAST_NAME varchar(25),FIRST_NAME varchar(25) not null,DEPT_ID numeric(7) )
VALUES(101,'Sam','Sundar',10),
(101,'Ram','Krishna',20),
(102,'Gopi',null,40),
(103,null,'ram',20);