CREATE TABLE DEPT
(Dept_ID numeric(7) PRIMARY KEY,Dept_Name varchar(20));