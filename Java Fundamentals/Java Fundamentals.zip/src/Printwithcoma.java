
public class Printwithcoma {
public static void main(String args[])
{
	  System.out.println(args[0]+",");

	  System.out.print(args[1]);
}
}
