
public class AlphabetDigitChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char a='t';
if(a>=65 && a<=90 || a>=96 && a<=122)
	System.out.println("Alphabet");
else if(a>=48 && a<=57)
	System.out.println("Digit");
else
	System.out.println("Special Character");
	}

}
