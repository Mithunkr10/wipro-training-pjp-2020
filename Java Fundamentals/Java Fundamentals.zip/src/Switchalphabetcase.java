
public class Switchalphabetcase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char a='i';
if(Character.isLowerCase(a))
{
	System.out.println(Character.toUpperCase(a));
}
else
	System.out.println(Character.toLowerCase(a));
	}

}
