
public class Alphabeticalorder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char a='h';
char b='u';
if(a<b)
	System.out.println(a+","+b);
else
	System.out.println(b+","+a);
	}

}
