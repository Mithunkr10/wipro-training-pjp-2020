class AcceptString

{

 public static void main(String args[])

 {

  System.out.println(args[0]+" technologies ");

  System.out.print(args[1]);

   }

}