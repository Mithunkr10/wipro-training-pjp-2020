
public class Asciitostring {
    public static void main(String args[]){
        int num[] = {65, 120, 98, 75, 115};
        for(int i: num){
            System.out.println((char)i);
        }
    }
}
