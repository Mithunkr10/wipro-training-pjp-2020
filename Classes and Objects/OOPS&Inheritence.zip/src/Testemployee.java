
public class Testemployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person("Mithun");
		Employee e=new Employee(1111111.999,"2019","12345","Mithun");
System.out.println(p.putname());
System.out.println(e.putter());
	}

}
