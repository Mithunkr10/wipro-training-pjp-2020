
public class Person {
String name;
Person(String n)
{
	name=n;
}
public String putname()
{ 
	return "Person Name:"+name;
	
}


}
