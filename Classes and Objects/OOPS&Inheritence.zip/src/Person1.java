
public class Person1 {
String name,dob;

public Person1(String n,String d)
{
	name=n;
	dob=d;
}
public String putter()
{
	return "Name:"+name+"DOB"+dob;
}
}

