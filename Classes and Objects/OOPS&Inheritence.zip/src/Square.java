
public class Square extends Shapes {
	void draw()
	{
		System.out.println("Drawing Sqaure");
	}
	void erase()
	{
		System.out.println("Erasing Square");
	}
}
