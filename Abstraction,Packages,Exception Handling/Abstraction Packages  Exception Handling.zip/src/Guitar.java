
public class Guitar extends Instrument {

	@Override
	public String play() {
		// TODO Auto-generated method stub
		return "Guitar is playing  tin  tin  tin ";
	}

}
