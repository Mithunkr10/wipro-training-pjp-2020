
public class Flute extends Instrument {

	@Override
	public String play() {
		// TODO Auto-generated method stub
		return "Flute is playing  toot toot toot toot";
	}

}
