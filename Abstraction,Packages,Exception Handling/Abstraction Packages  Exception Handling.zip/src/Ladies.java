
public class Ladies extends Compartments{

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return "Ladies Compartment";
	}

}
