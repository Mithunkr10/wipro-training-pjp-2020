
public class General extends Compartments {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return "General Compartment";
	}

}
