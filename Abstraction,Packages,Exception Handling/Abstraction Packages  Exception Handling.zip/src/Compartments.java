

public abstract class Compartments {

	public abstract String notice();
	
	


}
