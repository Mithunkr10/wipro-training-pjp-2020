
public class Piano extends Instrument {

	@Override
	public String play() {
		// TODO Auto-generated method stub
		return "Piano is playing  tan tan tan tan";
	}

}
