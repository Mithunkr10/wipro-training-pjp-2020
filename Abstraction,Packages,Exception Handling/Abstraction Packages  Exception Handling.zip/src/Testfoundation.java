import testpackage.Foundation;
public class Testfoundation extends Foundation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * System.out.println(testpackage.Foundation.var1);
		 * System.out.println(testpackage.Foundation.var2);
		 * System.out.println(testpackage.Foundation.var3);
		 */
		System.out.println(testpackage.Foundation.var4);

	}

}
