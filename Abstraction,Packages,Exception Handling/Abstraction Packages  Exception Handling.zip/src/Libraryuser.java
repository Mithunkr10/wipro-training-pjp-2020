
public interface Libraryuser {

		void registerAccount();

		void requestBook();
	
}
