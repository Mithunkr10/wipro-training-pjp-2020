
public class Luggage extends Compartments {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return "Luggage Compartment";
	}

}
